package OpenTracing::Interface;

our $VERSION = '0.11';

1;
