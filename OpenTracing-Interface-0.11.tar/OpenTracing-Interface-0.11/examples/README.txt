to run the example check:

> cd examples
> perl -I../lib MyTracer/Check.pm
